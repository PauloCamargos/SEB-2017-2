# Sinais e Sistemas em Engenharia Biomédica
>Sketches criados para a disciplina "Sinais e Sistemas em Engenharia Biomédica" do curso de Engenharia Biomédica

Os códigos estão bastante bagunçados, em alguns projetos está o codigo para
arduino, em outros o código utilizando a rapberry-pi. Alguns de maneira mais
simples e outros de maneira mais elaborada.

Idealmente, use como guia. Caso fique preso no desenvolvimento do seu projeto,
dê uma olhada aqui e se inspire.

## Contato
* **Italo Fernandes** - italogsfernandes@gmail.com
* **Paulo Camargos**
* Special thanks to **Ronaldo Sena** ([GitHub](http://github.com/ronaldosena)) for initializing this project.

```
"THE BEERWARE LICENSE" (Revision 42):
Ronaldo Sena started this code in 2016, Italo Fernandes and
Paulo Camargos continued his project in 2017. As long as
you retain this notice, you can do whatever you want with
this stuff. If we meet someday, and you think this stuff is
worth it, you can buy us a beer in return.
```
